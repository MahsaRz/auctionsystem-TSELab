-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 24, 2020 at 07:10 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `auctionsystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `auctions`
--

CREATE TABLE `auctions` (
  `auctionID` bigint(20) NOT NULL,
  `sellerID` bigint(20) NOT NULL,
  `buyerID` bigint(20) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `description` varchar(10000) NOT NULL,
  `startingBid` double NOT NULL,
  `reserveBid` double NOT NULL,
  `address` varchar(255) NOT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `zip` varchar(10) NOT NULL,
  `isActive` tinyint(1) DEFAULT 1,
  `buyPrice` double DEFAULT NULL,
  `startingDate` datetime NOT NULL DEFAULT current_timestamp(),
  `endingDate` datetime DEFAULT NULL,
  `imageFileName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `auctions`
--

INSERT INTO `auctions` (`auctionID`, `sellerID`, `buyerID`, `title`, `subtitle`, `description`, `startingBid`, `reserveBid`, `address`, `address2`, `country`, `state`, `zip`, `isActive`, `buyPrice`, `startingDate`, `endingDate`, `imageFileName`) VALUES
(22, 1, NULL, 'Binoculars', '', 'Old pair of binoculars that belonged to a \"Poilu\" during World War I 14-18. Still functional. Correct condition. For lovers of military objects, militaria.', 100, 75, '1275 Market Street', 'San Francisco', 'United States', 'California', '94103', 1, NULL, '2020-11-23 02:27:00', NULL, '1606058811-image_0007.jpg'),
(25, 1, NULL, 'Vintage Camera', '', 'A vintage 1950&#39;s era Zenith AM / FM radio with a  brown case. It is working. Measures 15&#34; 8.5&#34; x 8&#34;.', 200, 175, '1982 Crawford Street', '', 'Canada', 'Yukon', '98567', 1, NULL, '2020-11-23 04:33:32', NULL, '1606086212-image_0050.jpg'),
(26, 3, NULL, 'Buddha Idol', '', 'Green Tara, one of the eleventh mothers, Tibetan Buddha from Tibetan Collection of Old Buddha Statues', 500, 400, '198-B Bagtok Street', 'Saskatoon', 'Canada', 'Saskatchewan', '98754', 1, NULL, '2020-11-24 05:11:28', NULL, '1606174888-image_0003.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `bids`
--

CREATE TABLE `bids` (
  `bidID` bigint(20) NOT NULL,
  `bidderID` bigint(20) NOT NULL,
  `auctionID` bigint(20) NOT NULL,
  `bidTime` datetime NOT NULL DEFAULT current_timestamp(),
  `amount` float NOT NULL,
  `Name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `bids`
--

INSERT INTO `bids` (`bidID`, `bidderID`, `auctionID`, `bidTime`, `amount`, `Name`) VALUES
(3, 3, 22, '2020-11-24 02:54:30', 120, 'Test User 2'),
(4, 4, 25, '2020-11-24 03:58:04', 250, 'Test User 3'),
(5, 3, 25, '2020-11-24 03:58:25', 251, 'Test User 2'),
(6, 4, 22, '2020-11-24 03:58:37', 125, 'Test User 3');

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE `countries` (
  `country` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `countries`
--

INSERT INTO `countries` (`country`, `state`) VALUES
('United States', 'Alabama'),
('United States', 'Alaska'),
('United States', 'Arizona'),
('United States', 'Arkansas'),
('United States', 'California'),
('United States', 'Colorado'),
('United States', 'Connecticut'),
('United States', 'Delaware'),
('United States', 'Florida'),
('United States', 'Georgia'),
('United States', 'Hawaii'),
('United States', 'Idaho'),
('United States', 'Illinois'),
('United States', 'Indiana'),
('United States', 'Iowa'),
('United States', 'Kansas'),
('United States', 'Kentucky'),
('United States', 'Louisiana'),
('United States', 'Maine'),
('United States', 'Maryland'),
('United States', 'Massachusetts'),
('United States', 'Michigan'),
('United States', 'Minnesota'),
('United States', 'Mississippi'),
('United States', 'Missouri'),
('United States', 'Montana'),
('Canada', 'Alberta'),
('Canada', 'British Columbia'),
('Canada', 'Manitoba'),
('Canada', 'New Brunswick'),
('Canada', 'Newfoundland'),
('Canada', 'Northwest Territories'),
('Canada', 'Nova Scotia'),
('Canada', 'Nunavut'),
('Canada', 'Ontario'),
('Canada', 'Prince Edward Island'),
('Canada', 'Quebec'),
('Canada', 'Saskatchewan'),
('Canada', 'Yukon');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notificationID` bigint(20) NOT NULL,
  `type` varchar(50) NOT NULL,
  `auctionID` bigint(20) NOT NULL,
  `receiverID` bigint(20) NOT NULL,
  `isSeen` tinyint(1) NOT NULL DEFAULT 0,
  `dateAdded` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notificationID`, `type`, `auctionID`, `receiverID`, `isSeen`, `dateAdded`) VALUES
(6, 'Item Sold', 22, 1, 0, '2020-11-24 06:58:30'),
(7, 'Bid Won', 22, 4, 0, '2020-11-24 06:58:30'),
(8, 'Item Sold', 25, 1, 0, '2020-11-24 06:58:30'),
(9, 'Bid Won', 25, 3, 0, '2020-11-24 06:58:30');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `userID` bigint(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `signUpDate` datetime NOT NULL DEFAULT current_timestamp(),
  `isApproved` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`userID`, `name`, `email`, `password`, `signUpDate`, `isApproved`) VALUES
(1, 'Test User 1', 'testuser1@email.com', '$2y$10$b/6INff7dVHqJSpa0WwOEOaIVygH0mhehDsE0i/pL0LzfJOtjgUY6', '2020-11-21 17:24:36', 0),
(3, 'Test User 2', 'testuser2@email.com', '$2y$10$cD19dNV5v74fSZ2x/nv8DuJi9DuZ/bGAbl0PucEXxcdtfJ0bnPf.y', '2020-11-23 07:08:44', 0),
(4, 'Test User 3', 'testuser3@gmail.com', '$2y$10$YqHHs7zUJvGptyL/5.yx0u7FeEGgkMdeYuGY3tMvCcz86g9xMhfIC', '2020-11-24 03:56:21', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `auctions`
--
ALTER TABLE `auctions`
  ADD PRIMARY KEY (`auctionID`);

--
-- Indexes for table `bids`
--
ALTER TABLE `bids`
  ADD PRIMARY KEY (`bidID`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notificationID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`userID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `auctions`
--
ALTER TABLE `auctions`
  MODIFY `auctionID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `bids`
--
ALTER TABLE `bids`
  MODIFY `bidID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notificationID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `userID` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
