<?php
    require_once '../app/bootstrap.php';

    // initialize core library
    $init = new Core;