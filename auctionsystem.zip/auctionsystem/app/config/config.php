<?php
    // database parameters
    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'auctionsystem');

    // application root
    define('APPROOT', dirname(dirname(__FILE__)));

    // application root
    define('PROJECTROOT', dirname(dirname(dirname(__FILE__))));

    // url root
    define('URLROOT', 'http://localhost/auctionsystem');

    // site name
    define('SITENAME', 'AuctionSystem');

    // application version
    define('APPVERSION', '1.0.0');